# slic-reveng
A computational framework for reverse-engineering subject-level neuroimaging data from meta-analytic summary statistics and interpolating to vertexwise resolution.
